
package dashboard;


import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import login.LoginScreenController;

public class MainScreenController implements Initializable {

   
    @FXML
    private Label name;
    @FXML
    private Label body;
   public void setInfo()
    {
         Connection con=null;
        PreparedStatement ps= null;
        ResultSet rs=null;
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
            String sql="SELECT * FROM userdata WHERE AccountNo=? ";
            ps=con.prepareStatement(sql);
            
            ps.setString(1, LoginScreenController.acc);//
   
            rs=ps.executeQuery();
            
            if(rs.next())
            {
              name.setText(rs.getString("Name"));
              
              
            }
            else
            {
             Alert a= new Alert(Alert.AlertType.ERROR);
            a.setTitle("Error");
            a.setHeaderText("Error in login ");
            a.setContentText("Your account number or password is wrong. Enter again!!.");
            a.showAndWait();  
            }
            
            
              
            
            
        }catch(Exception e)
        {
            Alert a= new Alert(Alert.AlertType.ERROR);
            a.setTitle("Error");
            a.setHeaderText("Error in creating account");
            a.setContentText("Your account is not created there is some technical issue"+e.getMessage());
            a.showAndWait();
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       body.setText("Wonder Bank  provides loan with very less interest.It has different\nbranches in different parts of our country.It serves over 100\nmillion customers with 41,620 employees, 5,744 branches with 5,428\nATMs and Cash deposit machines and is one of the top performing\npublic sector banks. Total business of the bank has touched\n₹1,010,000 crore (US$130 billion) till date. It was stablished in\n 2000.");
      setInfo();
    }    
    
}
