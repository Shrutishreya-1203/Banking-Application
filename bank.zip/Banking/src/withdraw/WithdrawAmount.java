
package withdraw;

public class WithdrawAmount {
    
}
